#ifdef __cplusplus
extern "C" {
#endif
#include "AT.h"
#include "BlueNRG1_gpio.h"
#include "BlueNRG1_uart.h"
#include <string.h>
#include <stdarg.h>
#include "BlueNRG1_sysCtrl.h"
#include "clock.h"
#include "misc.h"
#include "BlueNRG1_mft.h"

#ifdef __cplusplus
}
#endif

AT::AT(    /* args */    )
{
}

AT::~AT()
{
}

void AT::InitGPIO(){
     SysCtrl_PeripheralClockCmd(CLOCK_PERIPH_GPIO | CLOCK_PERIPH_UART, ENABLE);

    GPIO_InitType ig;
    ig.GPIO_HighPwr = ENABLE;
    ig.GPIO_Mode = GPIO_Output;
    ig.GPIO_Pull = ENABLE;
    ig.GPIO_Pin = GPIO_Pin_3;
    GPIO_Init(&ig);
}
void AT::InitUart(uint32_t speed){
    SysCtrl_PeripheralClockCmd(CLOCK_PERIPH_GPIO | CLOCK_PERIPH_UART, ENABLE);

    GPIO_InitType ig;
    ig.GPIO_HighPwr = DISABLE;
    ig.GPIO_Mode = Serial1_Mode;
    ig.GPIO_Pull = DISABLE;
    ig.GPIO_Pin = GPIO_Pin_8;
    GPIO_Init(&ig);
    ig.GPIO_Pin = GPIO_Pin_11;
    GPIO_Init(&ig);

    UART_InitType iu;
    iu.UART_BaudRate = speed;
    iu.UART_FifoEnable = ENABLE;
    iu.UART_HardwareFlowControl = UART_HardwareFlowControl_None;
    iu.UART_Mode = UART_Mode_Rx | UART_Mode_Tx;
    iu.UART_Parity = UART_Parity_No;
    iu.UART_StopBits = UART_StopBits_1;
    iu.UART_WordLengthReceive = UART_WordLength_8b;
    iu.UART_WordLengthTransmit = UART_WordLength_8b;

    UART_Cmd(ENABLE);
    UART_Init(&iu);
    UART_RxFifoIrqLevelConfig(FIFO_LEV_1_64);

    SendMessage("\r");

}

void AT::AddChar(char c){
    if( rawBufferCounter < 200)
        rawBuffer[rawBufferCounter++]  = c;

    if ( c == '\r' || c == '\n' || bufferCounter >= maxSize){
        memcpy( message, buffer, maxSize);
        memset(buffer, 0, maxSize);

        newMessage = true;
        bufferCounter = 0;
    }else{
        buffer[bufferCounter++] = c;
    }
}

void AT::SendRawData(uint8_t *data, uint8_t len){
    tClockTime time;
    for( int index = 0; index < len; index++){
        time = Clock_Time();
        if( UART_GetFlagStatus(UART_FLAG_TXFF) == SET){
            if( Clock_Time() > time + 500) return;
        }
        UART_SendData(data[index]);
    }

}
void AT::SendFormatedMessage(char *msg){
    tClockTime time;
    for( int index = 0; index < strlen(msg); index++){
        time = Clock_Time();
        if( UART_GetFlagStatus(UART_FLAG_TXFF) == SET){
            if( Clock_Time() > time + 5500) return;
        }
        UART_SendData(msg[index]);
    }
    Clock_Wait(40);
}
void AT::SendMessage(char *msg, ...){
    char localBuffer[100];
    
    va_list args;
    va_start(args, msg);

    vsprintf(localBuffer, msg, args);

    va_end(args);

    SendFormatedMessage(localBuffer);

}
void AT::SendMessage(uint8_t *msg, ...){
    // char localBuffer[100];
    
    va_list args;
    va_start(args, msg);

    // vsprintf(localBuffer, msg, args);
    SendMessage((unsigned char*)msg,args);

    va_end(args);

    // SendMessage(localBuffer);

}


void AT::InitIRQ(){
    NVIC_InitType in;
    in.NVIC_IRQChannel = UART_IRQn;
    in.NVIC_IRQChannelCmd = ENABLE;
    in.NVIC_IRQChannelPreemptionPriority = LOW_PRIORITY;
    NVIC_Init(&in);
    UART_ITConfig(UART_IT_RX, ENABLE);

    
}

void AT::clearRawBuffer(){
    memset(rawBuffer, 0, 200);
    rawBufferCounter = 0;
}

void AT::ParseCommand(){

    for( int index = 0; index < numberOfCommandElements; index++)
        memset(command[index], 0, commandElementMaxSize);

    char temp[maxSize];
    memcpy(temp,message,maxSize);

    char *p = strtok(temp, ":");

     for( int index = 0; index < numberOfCommandElements; index++){
         if( strlen(p) == 0) return;

        sprintf((char*)command[index], "%s",p);
        p = strtok(NULL,":");
     }


}

bool AT::validATCommand(){

    return command[0][0] != 0 && 
           command[1][0] != 0 &&
           strcmp((const char*)command[0], "AT") == 0;
}

 
bool AT::validATCommand(uint8_t count, ...){
    
    if( !validATCommand()) return false;

    bool result = true;
    va_list args;

    va_start(args,count);

    for( uint8_t index = 0; index < count; index++){
        if( strcmp( (const char*)command[index + 1], va_arg(args, const char*)) != 0 ){
            result = false;
            break;
        }
    }
    va_end(args);
    return result;
}


bool AT::validClientCommand(){

    return command[0][0] != 0;  
           
}

 
bool AT::validClientCommand(uint8_t count, ...){
    
    if( !validClientCommand()) return false;

    bool result = true;
    va_list args;

    va_start(args,count);

    for( uint8_t index = 0; index < count; index++){
        if( strcmp( (const char*)command[index ], va_arg(args, const char*)) != 0 ){
            result = false;
            break;
        }

    }
    va_end(args);
    return result;
}
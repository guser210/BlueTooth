#ifdef __cplusplus
extern "C" {
#endif
#include <stdio.h>
#include "maincpp.h"
#include "AT.h"
#include "bluenrg1_api.h"
#include "clock.h"

#include "ble_config.h"
#include "bluenrg1_stack.h"

#include "Bluetooth.h"
#include "BlueNRG1_uart.h"
void handleRXIRQ();
#ifdef __cplusplus
}
#endif

Bluetooth *ptrBle;

void maincpp(){
    SystemInit();

    Clock_Init();

    BlueNRG_Stack_Initialization(&BlueNRG_Stack_Init_params);

    AT pico;

    pico.InitUart(115200);
    pico.InitGPIO();
    pico.SendMessage("main loop\r");

    Bluetooth ble("guser210 BlueNRG Device");
    ptrBle = &ble;
    ble.InitDevice();
    ble.AddService();

    pico.InitIRQ();

    pico.SendMessage("----\r");
    pico.SendMessage("Host Command\r");
    pico.SendMessage("trun on LED = AT:P3?\\r\r");
    pico.SendMessage("trun on LED = AT:P3:ON\\r\r");
    pico.SendMessage("trun off LED = AT:P3:OFF\\r\r");
    pico.SendMessage("SET device name = AT:NAME:NEWNAME\\r\r");
    pico.SendMessage("Device name = AT:NAME?\\r\r");
    pico.SendMessage("Conn status = AT:CONNECTED?\\r\r");
    pico.SendMessage("----\r");
    pico.SendMessage("Client Command\r");
    pico.SendMessage("trun on LED = P3:ON\\r\r");
    pico.SendMessage("trun off LED = P3:OFF\\r\r");
    while(1){

        Clock_Wait(50);

        BTLE_StackTick();

        ble.Tick();

    }
}

void handleRXIRQ(){
    ptrBle->HandleIRQRX();
}

void hci_le_connection_complete_event(uint8_t Status,
                                      uint16_t Connection_Handle,
                                      uint8_t Role,
                                      uint8_t Peer_Address_Type,
                                      uint8_t Peer_Address[6],
                                      uint16_t Conn_Interval,
                                      uint16_t Conn_Latency,
                                      uint16_t Supervision_Timeout,
                                      uint8_t Master_Clock_Accuracy){
    ptrBle->Connection( Connection_Handle);                                              
}

void hci_disconnection_complete_event(uint8_t Status,
                                      uint16_t Connection_Handle,
                                      uint8_t Reason){
     ptrBle->Connection(0);
     

}
void aci_gatt_attribute_modified_event(uint16_t Connection_Handle,
                                       uint16_t Attr_Handle,
                                       uint16_t Offset,
                                       uint16_t Attr_Data_Length,
                                       uint8_t Attr_Data[]){

                                        

    ptrBle->serialRX(Attr_Data, Attr_Data_Length, Attr_Handle);     
    ptrBle->clientRX(Attr_Data, Attr_Data_Length, Attr_Handle);     
    

    
}

void aci_gatt_tx_pool_available_event(uint16_t Connection_Handle,
                                      uint16_t Available_Buffers){

}
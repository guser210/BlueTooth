#ifdef __cplusplus
extern "C" {
#endif
#include "Bluetooth.h"
#include "bluenrg1_api.h"
#include "BlueNRG1_sysCtrl.h"
#include "clock.h"
#include "misc.h"
#include "BlueNRG1_uart.h"
#include <string.h>
#include "ble_const.h"
#include "BlueNRG1_gpio.h"
#include "hal_types.h"


#ifdef __cplusplus
}
#endif

Bluetooth::Bluetooth( const char *name   )
{
    setDeviceName(name);
}

Bluetooth::~Bluetooth()
{
}
 void Bluetooth::setDeviceName( const char *name){
    memset(deviceName, 0, sizeof(deviceName));
    memcpy( deviceName, name, strlen(name));
 }
void Bluetooth::InitDevice(){
    aci_hal_write_config_data(0, sizeof(deviceAddress), deviceAddress);

    aci_hal_set_tx_power_level(1,4);

    aci_gatt_init();

    aci_gap_init(1, 0, sizeof( deviceName), &gapServiceHandle, &gapCharHandle, &gapCharAppearanceHandle);

    aci_gatt_update_char_value_ext(0, gapServiceHandle, gapCharHandle, 0, sizeof(deviceName), 0, sizeof(deviceName), deviceName);

}

void Bluetooth::AddService(){
    uint8_t ret = 0;

    Service_UUID_t sid;
    memcpy(&sid.Service_UUID_16, serviceID, 2);
    ret = aci_gatt_add_service(UUID_TYPE_16, &sid,
                                  1, 8, &serviceHandle);  

    //  serial.SendMessage("service = x%02x\r",ret);

    Char_UUID_t cid;
    memcpy(&cid.Char_UUID_16, charSerialID, 2);
    aci_gatt_add_char(serviceHandle,
                    UUID_TYPE_16,
                    &cid,
                    20,
                    CHAR_PROP_NOTIFY | CHAR_PROP_READ | CHAR_PROP_WRITE_WITHOUT_RESP,
                    0,
                    GATT_NOTIFY_ATTRIBUTE_WRITE,
                    16, 1, &charSerialHandle);
    //  serial.SendMessage("Serial Char = x%02x\r",ret);

    Clock_Wait(100);
    uint8_t desc1[30] =  {"guser210 - Serial Interface"};
    Char_Desc_Uuid_t cdid;
    uint16_t descid = CHAR_USER_DESC_UUID;
    memcpy( &cdid.Char_UUID_16, &descid, 2);
    aci_gatt_add_char_desc(serviceHandle, 
                        charSerialHandle,
                        UUID_TYPE_16,
                        &cdid,
                        sizeof(desc1),
                        sizeof(desc1),
                        desc1,
                        0, 1,0, 16, 0, &descSerialHandle);
    // serial.SendMessage("Serial Desc = x%02x\r",ret);
//////////////////////////////

    memcpy(&cid.Char_UUID_16, charATID, 2);
    aci_gatt_add_char(serviceHandle,
                    UUID_TYPE_16,
                    &cid,
                    20,
                    CHAR_PROP_WRITE_WITHOUT_RESP ,
                    0,
                    GATT_NOTIFY_ATTRIBUTE_WRITE,
                    16, 1, &charATHandle);
    // serial.SendMessage("AT Char = x%02x\r",ret);


    uint8_t desc2[] =  {"guser210 - AT Command Interface"};

    memcpy( &cdid.Char_UUID_16, &descid, 2);
    aci_gatt_add_char_desc(serviceHandle, 
                        charATHandle,
                        UUID_TYPE_16,
                        &cdid,
                        sizeof(desc2),
                        sizeof(desc2),
                        desc2,
                        0, 1,0, 16, 0, &descATHandle);
    // serial.SendMessage("AT Desc = x%02x\r",ret);

}

void Bluetooth::Tick(){
    if( clientConnection != 0 && serial.rawBufferCounter > 0){
        SendClientData();
    }
    ProcessSerialCommands();


    uint8_t mdata[6 + sizeof(deviceName)] = {
        3, 3, 0xe0, 0xaa,
        sizeof(deviceName) + 1,
        9
    };

    memcpy(mdata + 6, deviceName, sizeof(deviceName));

    hci_le_set_scan_response_data(sizeof(mdata), mdata);

    aci_gap_set_discoverable(ADV_IND, 100, 1000, 0, 0, 
                            sizeof(deviceName), deviceName, 0, NULL, 0, 0);

    aci_gap_update_adv_data(sizeof(mdata), mdata);                            

}
void Bluetooth::SendClientData(){
        uint8_t buffer[serial.rawBufferCounter + 1] = {0};
        
        memcpy(buffer, serial.rawBuffer, serial.rawBufferCounter);
        
        serial.clearRawBuffer();
        
        int iLen = 0;
        uint8_t *ptr = buffer;
        while( strlen((const char*)ptr) > 0){
            iLen = strlen((const char*)ptr) > 20 ? 20 : strlen((const char*)ptr);
            
            aci_gatt_update_char_value_ext(clientConnection,
                                            serviceHandle, 
                                            charSerialHandle, 
                                            1, iLen, 0, iLen,ptr);
                                            

            ptr = (ptr + iLen);
        }

}
void Bluetooth::ProcessSerialCommands(){
    if( serial.newMessage != true) return;

    serial.ParseCommand();
    serial.newMessage = false;

    // Simple serial command implementation.
    if( serial.validATCommand(1, "P3?")){
        serial.SendMessage("P3:%d\r", GPIO_ReadBit(GPIO_Pin_3));

    }else if( serial.validATCommand(2, "P3","ON")){
        GPIO_WriteBit(GPIO_Pin_3, Bit_SET);

    }else if( serial.validATCommand(2, "P3","OFF")){
        GPIO_WriteBit(GPIO_Pin_3, Bit_RESET);

    }else if( serial.validATCommand(1,"NAME")){
        setDeviceName((const char*)serial.command[2]);
        serial.SendMessage( "NAME:%s\r",deviceName);

    }else if( serial.validATCommand(1,"NAME?")){
        serial.SendMessage( "NAME:%s\r",deviceName);

    }else if( serial.validATCommand(1,"CONNECTED?")){
        serial.SendMessage("CONNECTED:%s\r",clientConnection > 0 ? "Yes" : "No");

    }
    
}

void Bluetooth::HandleIRQRX(){
    char c = 0;
    if(UART_GetITStatus(UART_IT_RX) != RESET){
        while( !UART_GetFlagStatus(UART_FLAG_RXFE)){
            c = (uint8_t)(UART_ReceiveData() & 0xff);
            
            serial.AddChar(c);
        }
    }

}

void Bluetooth::Connection(uint16_t connection){
    clientConnection = connection;
    serial.SendMessage("Connection = x%04x\r", clientConnection);
}

void Bluetooth::serialRX( uint8_t *data, uint8_t len, uint16_t Attr_Handle){
    if( charSerialHandle + 1 == Attr_Handle)
        serial.SendRawData(data, len);
}

void Bluetooth::clientRX(uint8_t *data, uint8_t len, uint16_t Attr_Handle){
    if( charATHandle + 1 != Attr_Handle) return;
        
    for( int index = 0; index < len; index++)
        clientCommand.AddChar(data[index]);

    if( clientCommand.newMessage != true) return;

    clientCommand.ParseCommand();
    clientCommand.newMessage = false;

    // Simple client command implementation.
    if( clientCommand.validClientCommand(2, "P3","ON")){
        GPIO_WriteBit(GPIO_Pin_3, Bit_SET);
        serial.SendMessage("Client P3 cmd %s\r", clientCommand.command[1]);

    }else if( clientCommand.validClientCommand(2, "P3","OFF")){
        GPIO_WriteBit(GPIO_Pin_3, Bit_RESET);
        serial.SendMessage("Client P3 cmd %s\r", clientCommand.command[1]);
    }




}


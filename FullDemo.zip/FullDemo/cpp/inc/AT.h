
#include <stdio.h>
#ifndef __AT_H_
#define __AT_H_

class AT
{
private: // Vars.
    //TODO: Add private rars.
    const static uint8_t maxSize = 100;
    int bufferCounter = 0;
    uint8_t buffer[maxSize] = {0};
public: // Vars.
    //TODO: Add public vars.
    uint8_t message[maxSize] = {0};
    bool newMessage = false;
    uint8_t rawBuffer[200] = {0};
    uint8_t rawBufferCounter = 0;

    const static int numberOfCommandElements = 20;
    const static int commandElementMaxSize = 30;


private: // Funcs.
    //TODO: Add private funcs.
public: /// Funcs.
    //TODO: Add public funcs.
    uint8_t command[numberOfCommandElements][commandElementMaxSize] = {0};
    void InitUart(uint32_t speed);
    void AddChar(char c);
    void SendFormatedMessage(char *msg);
    void SendMessage(char *msg, ...);
    void SendMessage(uint8_t *msg, ...);
    void InitIRQ();
    void clearRawBuffer();
    void SendRawData(uint8_t *data, uint8_t len);
    void ParseCommand();
    bool validATCommand();
    bool validATCommand(uint8_t count, ...);
    bool validClientCommand();
    bool validClientCommand(uint8_t count, ...);

    void InitGPIO();
public:
    AT(    /* args */    );
    ~AT();
};




#endif

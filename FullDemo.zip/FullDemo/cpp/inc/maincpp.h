#ifdef __cplusplus
extern "C" {
#endif
void maincpp();
#ifdef __cplusplus
}
#endif

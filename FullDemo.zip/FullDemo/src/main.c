#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif
#include "maincpp.h"
#ifdef __cplusplus
}
#endif


int main(){

  maincpp();

  return 0;
}